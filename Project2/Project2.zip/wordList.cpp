/* Wordlist source file
*
*	This file will contain the function definitions you will implement.
*	The function signitures may NOT be changed.  You may create your own
*	helper functions and include them in this file.
*
*	In addition to the specific instructions for each function, no function
*	should cause any memory leaks or alias list in any way that would result
*	in undefined behavior. 
*
*	Topics: Multilevel Pointers, Dynamic Allocation, Classes
*
*/
// MS VS does not like cstring functions, this is to tell it to chill out.
#ifdef _MSC_VER  //  Microsoft Visual C++

#define _CRT_SECURE_NO_DEPRECATE

#else  // not Microsoft Visual C++, so assume UNIX interface

#endif
#define WORDLIST_H

#ifdef ONLINE_HELP
#define CLASS_PROJECT
#include"self_sabotage.h"
#else
// Do not include any other libraries
#include"wordlist.h"
#include<iostream>
#include<cstring>
using std::cout;
using std::endl;
using std::strcat;
using std::strcmp;
using std::strcpy;
using std::strlen;
#endif

// Function:  resize
int Wordlist::resize(int amt) {

	// --- TODO --- 
	if (amt < size) {
		return -1; // Cannot reduce size below the number of words stored
	}

	if (amt < 0 && size == 0) {
		return -2; // Cannot reduce allocated space below zero if there are no words stored
	}

	if (amt <= allocated) {
		return 0; // No need to resize
	}

	char** newList = new char* [amt];
	if (newList == nullptr) {
		return 3; // Unable to allocate memory for resizing
	}

	for (int i = 0; i < amt; ++i) {
		newList[i] = new char[MAX_WORD_SIZE];
		newList[i][0] = '\0';
	}

	for (int i = 0; i < size; ++i) {
		strcpy(newList[i], list[i]);
	}

	// Delete old list
	for (int i = 0; i < allocated; ++i) {
		delete[] list[i];
	}
	delete[] list;

	list = newList;
	allocated = amt;

	return 1; // Resized successfully
}

// Function: Wordlist Constructor
Wordlist::Wordlist(const int cap) {

	// --- TODO --- 
	if (cap < 1) {
		// If max is less than 1, set list to nullptr and initialize other members accordingly.
		list = nullptr;
		allocated = 0;
		size = 0;
	}
	else {
		// Allocate memory for the list of words based on the given max capacity.
		allocated = cap;
		list = new char* [cap];
		for (int i = 0; i < cap; ++i) {
			list[i] = new char[MAX_WORD_SIZE]; // Assuming MAX_WORD_SIZE is defined.
			list[i][0] = '\0'; // Initialize each word as an empty string.
		}
		size = 0; // Initially, there are no words in the list.
	}

}

// Function: Wordlist Copy Constructor
Wordlist::Wordlist(const Wordlist &other) {
    
	// --- TODO --- 
	allocated = other.allocated;
	size = other.size;

	if (allocated < 1) {
		list = nullptr;
	}
	else {
		list = new char* [allocated];
		for (int i = 0; i < allocated; ++i) {
			list[i] = new char[MAX_WORD_SIZE];
			// Copy each word from 'other' to the newly created list.
			strcpy(list[i], other.list[i]);
		}
	}
}

// Funtion: Assignment Operator
Wordlist& Wordlist::operator=(const Wordlist &other) {

	// --- TODO --- 
	if (this == &other) {
		// Self-assignment check, return *this to handle self-assignment safely.
		return *this;
	}

	// Deallocate the current resources
	for (int i = 0; i < allocated; ++i) {
		delete[] list[i];
	}
	delete[] list;

	// Copy attributes from src
	allocated = other.allocated;
	size = other.size;

	// Allocate new resources
	if (allocated < 1) {
		list = nullptr;
	}
	else {
		list = new char* [allocated];
		for (int i = 0; i < allocated; ++i) {
			list[i] = new char[MAX_WORD_SIZE];
			strcpy(list[i], other.list[i]);
		}
	}

	return *this; // Return a reference to the modified object

}

// Function: Wordlist Destructor.
Wordlist::~Wordlist() {
   
	// --- TODO --- 
	for (int i = 0; i < allocated; ++i) {
		delete[] list[i];
	}
	delete[] list;
	list = nullptr;

}

// Function: display
int	Wordlist::display() const {

	// --- TODO --- 
	if (list == nullptr) {
		return 0; // Nothing to display
	}

	for (int i = 0; i < size; ++i) {
		std::cout << list[i];
		if (i < size - 1) {
			std::cout << ' '; // Add a space between words except for the last word
		}
	}
	std::cout << std::endl; // Add a newline after the last word

	return size;
}

// Function: at
const char* Wordlist::at(const int index) const {

	// --- TODO --- 
	if (index >= 0 && index < size) {
		return list[index];
	}
	else {
		return nullptr; // Index is out of bounds
	}
}

// Function: stored
int	Wordlist::stored() const {

	// --- TODO ---
	return size; 
}

// Function: space
int	Wordlist::space() const {
	
	// --- TODO --- 
	 // Calculate the amount of space remaining in Wordlist
	return allocated - size;
}

// Function: insert
int	Wordlist::insert(const int index, const char word[]) {
    
	// --- TODO --- 
	if (list == nullptr) {
		return 1; // List is nullptr
	}

	if (index < 0) {
		// Insert into the front of the Wordlist
		if (size >= allocated) {
			// Need to resize
			int resizeResult = resize(allocated + 1);
			if (resizeResult != 0) {
				return resizeResult; // Unable to resize
			}
		}

		// Shift existing words to the right
		for (int i = size; i > 0; --i) {
			strcpy(list[i], list[i - 1]);
		}

		strcpy(list[0], word);
		++size;
		return 0; // Inserted successfully
	}
	else if (index >= size) {
		// Insert as the last word in the Wordlist
		if (size >= allocated) {
			// Need to resize
			int resizeResult = resize(allocated + 1);
			if (resizeResult != 0) {
				return resizeResult; // Unable to resize
			}
		}

		strcpy(list[size], word);
		++size;
		return 0; // Inserted successfully
	}
	else if (index >= 0 && index < size) {
		// Insert at the specified index
		if (size >= allocated) {
			// Need to resize
			int resizeResult = resize(allocated + 1);
			if (resizeResult != 0) {
				return resizeResult; // Unable to resize
			}
		}

		// Shift existing words to the right
		for (int i = size; i > index; --i) {
			strcpy(list[i], list[i - 1]);
		}

		strcpy(list[index], word);
		++size;
		return 0; // Inserted successfully
	}
	else {
		return 0; // Do nothing for empty word
	}
}

// Funtion: erase
int	Wordlist::erase(const char word[]) {

	// --- TODO --- 
	if (list == nullptr) {
		return -3; // List is nullptr
	}

	int erasedCount = 0;
	for (int i = 0; i < size; ++i) {
		if (strcmp(list[i], word) == 0) {
			// Word found, erase it by shifting the remaining words
			delete[] list[i];
			for (int j = i; j < size - 1; ++j) {
				list[j] = list[j + 1];
			}
			list[size - 1] = new char[MAX_WORD_SIZE];
			list[size - 1][0] = '\0';
			--size;
			++erasedCount;
		}
	}

	return erasedCount;
}

// Function: interleave
int	Wordlist::interleave(const Wordlist &other){

	if (list == nullptr || other.list == nullptr) {
		return -1; // Either list is nullptr
	}

	int totalWordsInterleaved = 0;
	int currentSize = size;

	// Calculate the total number of words to be interleaved
	int wordsToInterleave = other.size;

	// Check if resizing is needed
	if (size + wordsToInterleave >= allocated) {
		int resizeResult = resize(size + wordsToInterleave);
		if (resizeResult != 0) {
			return resizeResult; // Unable to resize
		}
	}

	// Shift words to make space for interleaved words
	for (int i = size - 1; i >= currentSize; --i) {
		strcpy(list[i + wordsToInterleave], list[i]);
	}

	// Interleave words from the other Wordlist
	for (int i = 0; i < wordsToInterleave; ++i) {
		strcpy(list[currentSize + i], other.list[i]);
		++totalWordsInterleaved;
	}

	size += wordsToInterleave;
	return totalWordsInterleaved;
}

// Function: search
int Wordlist::search(const char word[]) const {

	// --- TODO --- 
	if (list == nullptr) {
		return -2; // List is nullptr
	}

	for (int i = 0; i < size; ++i) {
		if (strcmp(list[i], word) == 0) {
			return i; // Word found, return its index
		}
	}

	return -1; // Word not found
}

// Funtion: sort
int	Wordlist::sort(const int mode) {
  
	// --- TODO --- 
	
	if (list == nullptr) {
		return -2; // List is nullptr
	}

	if (size <= 1) {
		return 0; // Nothing to sort
	}

	// Custom sorting algorithm
	for (int i = 0; i < size - 1; ++i) {
		for (int j = 0; j < size - i - 1; ++j) {
			int comparisonResult = strcmp(list[j], list[j + 1]);
			if ((mode == -1 && comparisonResult < 0) ||
				(mode == 1 && comparisonResult > 0) ||
				(mode == 0 && comparisonResult > 0)) {
				// Swap words if necessary
				char temp[MAX_WORD_SIZE];
				strcpy(temp, list[j]);
				strcpy(list[j], list[j + 1]);
				strcpy(list[j + 1], temp);
			}
		}
	}

	return 1; 
	// Sorting completed successfully
}
// Funtion: yoink
int	Wordlist::yoink(const char word[], Wordlist &other) {
	
	// --- TODO --- 
	if (list == nullptr || other.list == nullptr) {
		return -1; // Either list is nullptr
	}

	int indexToYoink = -1;

	// Find the index of the word to be yoinked in the other Wordlist
	for (int i = 0; i < other.size; ++i) {
		if (strcmp(other.list[i], word) == 0) {
			indexToYoink = i;
			break; // Found the word, no need to search further
		}
	}

	if (indexToYoink == -1) {
		return -1; // Word not found in the other Wordlist
	}

	// Check if resizing is needed
	if (size >= allocated) {
		int resizeResult = resize(allocated + 1);
		if (resizeResult != 0) {
			return resizeResult; // Unable to resize
		}
	}

	// Yoink the word from the other Wordlist
	strcpy(list[size], other.list[indexToYoink]);
	++size;

	// Shift words in the other Wordlist to fill the gap
	for (int i = indexToYoink; i < other.size - 1; ++i) {
		strcpy(other.list[i], other.list[i + 1]);
	}
	strcpy(other.list[other.size - 1], ""); // Clear the last element
	--other.size;

	return (size >= allocated) ? 1 : 0; // Return 1 if resize was needed, otherwise 0
}
