#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

//Insert your name is student id, letters and numbers only".
namespace StudentInfo {
	std::string Name() { return "Heavenly Franklin"; }
	std::string ID() { return "1735757"; }
};

#endif