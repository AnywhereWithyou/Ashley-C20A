#ifndef BIGBLINK_H
#define BIGBLINK_H

#include "life.h"

class BigBlink:public Life {
public:
	BigBlink(int r, int c);
	~BigBlink();
};


#endif 
