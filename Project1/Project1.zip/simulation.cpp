#include "simulation.h"

#include <iostream>
#include <string>
#include <cstdlib>
#include <chrono>
#include <thread>

#include "global.h"


Simulation::Simulation(Life** life, int numLife) {
	watchme = 1;
	steps = 0;
	automate = false;
	matrix = new Matrix();

	if (life != nullptr) {
		for (int i = 0; i < numLife; i++) {
			if (life[i] != nullptr) {
				bool success = matrix->initState(life[i]);
				if (!success) {
					std::cout << "Failed to add life to the matrix" << std::endl;
				}
			}
		}
	}
};
Simulation::~Simulation() {
	delete matrix;
};
void Simulation::simulate() {
	while (true) {
		matrix->render();

		if (!automate) {
			std::cout << "command (<space> to step, <a> to automate, <q> to quit): ";

			std::string action;
			std::getline(std::cin, action);

			switch (action[0])
			{

			default:
				std::cout << '\a' << std::endl;  // beep
				continue;
			case 'q':
				std::cout << "Quitting Game." << std::endl;
				return;
			case 's':

				continue;
			case ' ':

				break;
			case 'a':
				automate = true;
				break;
			}
		}
		else {
			if (steps >= MAX_STEPS) {
				std::cout << "Reached max steps, quitting." << std::endl;
				return;
			}
			delay(300);
		}
		steps++;
		matrix->computeNextState();
	}
};
void Simulation::report() {
	// Answers1 for Part 2: Analysis
	std::string msg = "\n1)Answers1 for Part 2: Analysis"; 
	std::cout << msg << std::endl;
	msg = "   The value of 'watchme' varible is changed from 1 to 7, 8, 2, 5.";
	std::cout << msg << std::endl;
	msg = "   So the identified entire five digit number is '52871' and the decoded sequence of characters was 'never goin to give you up'. \n\n";
	std::cout << msg << std::endl;

	// Answers2 for Part 2: Analysis
	msg = "\n2)Answers2 for Part 2: Analysis";
	std::cout << msg << std::endl;
	msg = "   - Incorrect Header File Names : Ensure that the names of the header files in the #include directives exactly match the actual filenames(including capitalization) and file extensions(usually.h for C++ header files).\n          Any deviation from the correct filename or extension will result in a compilation error.";
	std::cout << msg << std::endl;
	msg = "   - Syntax Errors in Header Files: If any of the included header files contain syntax errors or other issues, it can lead to compilation errors. \n          Check the content of each included header file for correctness.";
	std::cout << msg << std::endl;
	msg = "   - Circular Dependencies: If there are circular dependencies between the header files (e.g., Header A includes Header B, and Header B includes Header A), it can cause compilation errors. \n          Circular dependencies should be resolved using forward declarations or by reorganizing the code.";
	std::cout << msg << std::endl;
	msg = "   - Incorrect Header Guards: If any of the included header files have incorrect or missing include guards, it can lead to redefinition errors when included multiple times.\n          Make sure that each header file has proper include guards to prevent multiple inclusions.";
	std::cout << msg << std::endl;
	msg = "   - Build Configuration: The build configuration in your development environment may affect whether the compiler can find the header files.\n          Ensure that the project settings or build configuration is correctly set up to include the necessary directories and files.";
	std::cout << msg << std::endl;
	msg = "   - Compiler-Specific Behavior: Different compilers may have slightly different behaviors when it comes to handling header files and includes.\n          Ensure that the compiler being used is configured correctly.";
	std::cout << msg << std::endl;
	msg = "   - File Locations: Confirm that the header files are located in the specified directories or paths that the #include directives reference. \n          If the files are not in the expected locations, the compiler will not find them. \n\n";
	std::cout << msg << std::endl;

	// Answers3 for Part 3: Analysis
	msg = "\n3)Answers3 for Part 2: Analysis";
	std::cout << msg << std::endl;
	msg = "   - Dependency Chain: If matrix.h is included indirectly through other headers included in the project, the compiler might follow the dependency chain and include them automatically. \n          For example, if simulation.h includes matrix.h and simulation.h is included in main.cpp, the necessary headers could be indirectly included.";
	std::cout << msg << std::endl;
	msg = "   - Header Guards: If the header files matrix.h and simulation.h contain proper include guards (e.g., #pragma once or traditional #ifndef and #define guards), \n          the compiler may recognize that they have already been included elsewhere in the project and avoid duplicating the includes.\n\n";
	std::cout << msg << std::endl;

};
int Simulation::two(int u) {
	return (u << 2) % 10;
};
int Simulation::three(int x) {
	if (x % 2 == 0)
		return 5;
	else
		return 3;
};
void Simulation::one(int t) {
	int i = 0;
	int k = watchme;
	while (++i < t) {
		if (i == 0)
			k = 2;
		else if (i == 1)
			k = 7;
		else if (i == 4)
			k = 8;
		else if (i == 5)
			k = 5;
		else
			k = two(watchme);
		watchme = k;
	}
	k = three(watchme);
	watchme = k;
};
void Simulation::delay(int ms) const {
	std::this_thread::sleep_for(std::chrono::milliseconds(ms));
};