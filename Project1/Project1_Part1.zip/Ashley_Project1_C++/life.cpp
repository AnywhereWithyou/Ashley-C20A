#include "life.h"

#include <iostream>
#include <string>
#include <cstdlib>
#include <chrono>
#include <thread>

#ifdef _MSC_VER  // DO NOT BREAK APART THE IF PREPROCESSOR DIRECTIVES
	#include <windows.h> 
#else			
	#include <iostream>
	#include <cstring>
	#include <cstdlib>
#endif		

#include "global.h"
#include "matrix.h"
#include "simulation.h"

int Life::getCol() const {
	return col;
}
int Life::getRow() const {
	return row;
}
int Life::getHeight() const {
	return height;
}
int Life::getWidth() const {
	return width;
}
char Life::getFigure(int r, int c) const {
	return sprite[r][c];
}
void Life::inMatrix(Matrix* m) {
	matrix = m;
}
void Life::inSimulation(Simulation* s) {
	simulation = s;
}
bool Life::areWeInASimulation() {
	return simulation != nullptr;
}